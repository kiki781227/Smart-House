#include <WiFiNINA.h>

// Informations de connexion WiFi
char ssid[] = "Robotix";          // Nom du réseau WiFi
char password[] = "12345678";     // Mot de passe du WiFi
bool sysState = false;
WiFiServer server(80);            // Serveur sur le port 80


int LedTabTaille = 3;
int pinLedSalon[3] = {12,11,10};
int pinLedChambre[3] = {9,8,7};
int pinLedToilette[3] = {6,5,4};

bool horaireFixe = false; // Indique si les horaires du jour ont ete genere (true une fois definir et false apres 23h)
unsigned long heureActuelle;
unsigned long heuresExt[2]; // Les horaires ou la led de la chambre et toillete peuvent etre eteinte
unsigned long heuresAll[2];  // Les horaires ou tous les leds s'allument

int idxExtinction ;
int idxAllumage ;


// Prototype
void setupServeur();
String loopServeur();
void sendSysState(WiFiClient &client);
void sendPage(WiFiClient &client);
bool SystemeState();
void EteindreLed(int pintab[], int taille);
void AllumerLed(int pintab[], int taille);
void SetupLedPin(int pinTab[], int taille);
void AllumerRandomSalle(int numero, int duree);
int convertToSeconds(String time);

unsigned long debutEvenementChambre = 0;
unsigned long debutEvenementToilette = 0;
unsigned long dureeChambre = 0;
unsigned long dureeToilette = 0;
bool evenementChambreEnCours = false;
bool evenementToiletteEnCours = false;