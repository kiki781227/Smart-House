from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from urllib.parse import urlparse, parse_qs

# Variables globales
sysState = False  # État initial du système
last_time = None  # Heure reçue pour l'action

# Configuration du serveur
def setupServeur(port=8080):
    server_address = ('', port)
    httpd = HTTPServer(server_address, RequestHandler)
    print(f"Serveur démarré sur le port {port}")
    return httpd

# Classe pour gérer les requêtes HTTP
class RequestHandler(BaseHTTPRequestHandler):
    def log_request_details(self):
        # Afficher les détails de la requête
        print(f"\n--- Nouvelle requête reçue ---")
        print(f"Méthode : {self.command}")
        print(f"Chemin : {self.path}")
        print(f"En-têtes : {self.headers}")
        
        # Lire le corps de la requête (si disponible)
        content_length = int(self.headers.get('Content-Length', 0))
        if content_length > 0:
            body = self.rfile.read(content_length).decode('utf-8')
            print(f"Corps : {body}")
        else:
            print("Corps : Aucun")

    def do_POST(self):
        global sysState, last_time

        # Afficher les détails de la requête
        self.log_request_details()

        # Traiter les différentes routes
        if "/state" in self.path:
            self.sendSysState()

        elif "/bouton" in self.path:
            # Extraire l'heure de la requête
            parsed_path = urlparse(self.path)
            query_params = parse_qs(parsed_path.query)
            last_time = query_params.get("time", ["Non spécifiée"])[0]

            # Basculer l'état du système
            sysState = not sysState
            print(f"État du système basculé à {'Activé' if sysState else 'Désactivé'} à {last_time}")
            self.sendSysState()

        else:
            self.send_response(404)
            self.end_headers()

    def do_GET(self):
        # Afficher les détails de la requête
        self.log_request_details()

        # Répondre avec la page HTML
        if self.path == "/":
            self.sendPage()
        else:
            self.send_response(404)
            self.end_headers()

    def sendSysState(self):
        # Envoyer l'état du système en JSON
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        response = {"sysState": sysState, "last_time": last_time}
        self.wfile.write(json.dumps(response).encode("utf-8"))

    def sendPage(self):
        # Envoyer le contenu HTML tel quel
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        html = """
        <!DOCTYPE HTML>
        <html lang="fr">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Contrôle Système</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
            <style>
                #sent-time {
                    position: absolute;
                    top: 10px;
                    left: 10px;
                    font-size: 0.9rem;
                    font-weight: bold;
                    color: #6c757d;
                }
            </style>
        </head>
        <body class="text-center bg-light">
            <div id="sent-time">Dernière heure envoyée : aucune</div>
            <div class="container py-5">
                <h1 class="mb-4">Contrôler le système</h1>
                <button id="toggleButton" class="btn btn-primary btn-lg" onclick="SendAndControl()">Start</button>
                <div class="mt-4">
                    <span class="badge bg-secondary" id="status">État actuel : Système désactivé</span>
                </div>
            </div>
            <script>
                let sysState = false;
                function SendAndControl() {
                    const maintenant = new Date();
                    const temps = maintenant.toLocaleTimeString();
                    fetch('/bouton?time=' + temps, { method: 'POST' })
                        .then(response => response.json())
                        .then(data => {
                            sysState = data.sysState;
                            const button = document.getElementById('toggleButton');
                            const status = document.getElementById('status');
                            const sentTime = document.getElementById('sent-time');
                            sentTime.textContent = "Dernière heure envoyée : " + temps;
                            if (sysState) {
                                button.textContent = "Stop";
                                button.classList.replace("btn-primary", "btn-danger");
                                status.textContent = "État actuel : Système activé";
                                status.className = "badge bg-success";
                            } else {
                                button.textContent = "Start";
                                button.classList.replace("btn-danger", "btn-primary");
                                status.textContent = "État actuel : Système désactivé";
                                status.className = "badge bg-secondary";
                            }
                        })
                        .catch(err => console.error("Erreur :", err));
                }
                window.onload = function() {
                    fetch('/state', { method: 'POST' })
                        .then(response => response.json())
                        .then(data => {
                            sysState = data.sysState;
                            const button = document.getElementById('toggleButton');
                            const status = document.getElementById('status');
                            if (sysState) {
                                button.textContent = "Stop";
                                button.classList.replace("btn-primary", "btn-danger");
                                status.textContent = "État actuel : Système activé";
                                status.className = "badge bg-success";
                            } else {
                                button.textContent = "Start";
                                button.classList.replace("btn-danger", "btn-primary");
                                status.textContent = "État actuel : Système désactivé";
                                status.className = "badge bg-secondary";
                            }
                        })
                        .catch(err => console.error("Erreur :", err));
                };
            </script>
        </body>
        </html>
        """
        self.wfile.write(html.encode("utf-8"))

# Fonction principale pour démarrer le serveur
if __name__ == "__main__":
    server = setupServeur(port=8080)
    try:
        print("En attente des connexions...")
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nArrêt du serveur.")
        server.server_close()